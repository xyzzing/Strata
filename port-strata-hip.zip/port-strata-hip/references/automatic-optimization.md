# Automatic speed optimization contract

Implement these controls in the real checkout's existing wrapper/tests/state layer. This reference specifies engineering work; the skill itself does not execute a daemon, monitor a PC, or provide a tested optimizer.

## 1. Resolve the run contract once

Record GPU UUID/PCI identifiers, visible-device mapping, exact source/upstream/patch/compiler/library revisions, model hashes, tokenizer, quantization, context, sampling, active features and other workload ownership. Benchmark only devices authorized for this task. A change in any fingerprint component invalidates affected evidence.

Define the goal before search. Default to reducing geometric-mean warm end-to-end latency over a fixed, equally weighted workload set, while bounding each protected workload's regression. Suggested cases are short interactive decode, medium code prompt, and long research prompt, sized to the actual safe context limit. Pin prompts/seeds and output lengths; use forced-length benchmark requests only if supported and identical on both paths, and keep separate realistic completion tests. Never compare unequal completed work as a speedup. Record cold load, TTFT, prefill rate, decode rate, per-token latency, host/VRAM peaks and correctness separately.

Preserve the same model/quantization/quality setting; context reduction, cheaper quantization, token truncation and disabling requested functionality are separate user trade-offs, not kernel improvements. Allocate a finite run budget. Mark costs unknown when the selected agent cannot measure them.

## 2. Build a controller before unattended operation

Reuse the project's commands. Keep a machine-readable manifest with schema version, run ID, code/weights/environment fingerprints, policy hash and trial states. Store each command, exit status, duration, results and logs in a trial directory. Use atomic state writes and a lock so only one controller operates a checkout/device set. Redact secrets. Track build/download/storage budgets as well as runtime.

Check cancellation before launches and between trials. On timeout or interruption stop only owned process groups, collect diagnostics and mark the trial interrupted; never reinterpret a partial result as a pass. On resume, reap or identify owned remnants, invalidate incomplete metrics and verify fingerprints before continuing. Account for elapsed time across restarts so a crash does not reset the budget. Do not automatically rerun a crashing full-model workload.

Exercise controller tests before unattended runs: injected compile failure, incorrect numerical output, hanging child, cancellation, controller restart, exhausted budget, stale result fingerprint and failed generation stamp. Verify they preserve the baseline and produce explicit non-success states. Host device loss, GPU reset symptoms or unsafe memory pressure stop the run for diagnosis.

Observe available RAM/VRAM, cgroup limits and pinned allocations. Determine an absolute reserve from the desktop/services and measured startup/transient peak; the example policy deliberately leaves it unset. An unset/unknown reserve blocks full-model automatic trials. Use host process controls where appropriate and account for memory mapped/pinned pages; never assume a process memory cap fully protects GPU or locked memory. A detached service is lifecycle isolation, not proof against OOM.

## 3. Search in increasing risk order

| Phase | Candidate space | Constraint |
| --- | --- | --- |
| A | Existing legal batch/chunk sizes, CPU thread count, cache/placement budgets | Hold functional context/quality fixed; use measured memory admission |
| B | Existing kernel launch/tile variants | Filter by wave mode, datatype, layout, LDS/register limits |
| C | Targeted fusion, quantized GEMV/dequant, routing or QSA changes | One profiled hypothesis and independent parity per patch |
| D | Graph/overlap/speculative changes | Require ordering, rollback/state and active-feature validation |
| E | Dual-GPU placement/collectives | Separate scope, topology baseline and communication measurements |

Start with a small deterministic search rather than unrestricted generated code. Use isolated worktrees/build directories with shared read-only model artifacts where appropriate. Keep known-good generated HIP outputs and dependency versions reproducible. A candidate may change source/build settings but not reference outputs, tolerances, workload definitions or decision thresholds. Evaluation-code fixes require a separate reviewed change and re-baselining.

Rank hypotheses by measured request-time share, plausible headroom, development cost and correctness risk. Use Amdahl's law only as an upper-bound estimate. Inspect RDNA3 code generation/register spills only after traces identify a relevant kernel; do not import CUDA or CDNA launch constants by name.

## 4. Evaluate without rewarding noise

Correctness always gates speed. Run affected independent fixtures, boundary/adversarial cases and integration checks; required skipped checks block automatic acceptance. Model parity must cover changed paths, including PLE, expert format, routing, speculative verification and state rollback where active. A result with unresolved model parity can remain an experimental candidate but cannot become the validated default.

For timing, use at least two warmups and five interleaved baseline/candidate pairs per workload initially; alternate or deterministically randomize order. Measure without profiling instrumentation. Log temperatures/clocks and competing load; invalidate contaminated pairs under predeclared rules. Use GPU events for relevant device work and wall clock for request latency. Report all pairs and dispersion, not the fastest run.

Suggested initial decision rule (a tunable engineering policy, not a universal statistical guarantee): require at least 5% primary-score improvement; paired-bootstrap the workload aggregate and require its 95% interval to exclude zero improvement. Also require every protected workload's median latency regression to be at most 3% and all memory caps to hold. Five pairs are a screening minimum: ambiguous intervals trigger at most the configured maximum of 15 pairs, then mark inconclusive. Never keep sampling until favorable.

Hold out additional representative prompts/shapes and rerun a fresh final baseline comparison for finalists. Require the same predeclared latency/correctness gates on holdout; record its workload hashes. Do not tune on failing holdout, relabel it training data and immediately call the same candidate validated. Multiple candidate selection can overfit noise: independent confirmation is essential.

## 5. Promote, retain or roll back

A deterministic decision script consumes result JSON and immutable policy and returns accepted, rejected, inconclusive or blocked. Missing/nonfinite metrics, fingerprint mismatch, failed correctness or required skips cannot return accepted. Store baseline/candidate metrics and confidence interval, code diff, test coverage, memory margin and exact reproduction commands.

Accept means save a tested candidate as the local known-good checkpoint/configuration. It does not authorize public publication or replacement/restart of another running service. Re-run the combined configuration after accepting multiple changes; separate wins can interact. Preserve a one-command local rollback using recorded paths/configuration without destructive reset of user work.

Stop on budget exhaustion, repeated same-signature failures, three candidates without a qualifying gain, thermal/device fault, unsafe memory or a missing oracle. Resume from the checkpoint only with valid remaining budget. Report gains separately for prefill, decode, TTFT and whole requests; an inconclusive or slower result is a useful recorded outcome.

## Implementation handoff

Ask the local agent to implement only the next missing controller stage and prove its stop/recovery gates before increasing autonomy. Do not invent an `autotune` command if the wrapper lacks it. Prefer extending existing report/state formats over introducing another orchestration framework.

Optional profiler documentation: https://rocm.docs.amd.com/projects/rocprofiler-sdk/en/latest/how-to/using-rocprofv3.html
Inspect installed `rocprofv3 --help` and supported counters before constructing commands; successful profiling on an Instinct GPU is not evidence of Radeon counter support.
