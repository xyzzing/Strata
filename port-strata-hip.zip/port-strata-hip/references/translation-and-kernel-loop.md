# Translation checks and kernel experiments

Read when diagnosing translation gaps, upgrading HIPIFY or implementing an optimized kernel. Reviewed sources on 29 September 2026. Recheck options and support tables against the pinned toolchain before using them.

## Choose the translation tool deliberately

HIPIFY offers parser-based hipify-clang and simpler hipify-perl translation. AMD documents Perl limitations around macro expansion, namespaces, some templates, distinguishing host/device calls, header insertion and complex argument lists. Its absence of a CUDA dependency is useful for this AMD workstation.

Retain the fork's hash-pinned Perl workflow and declared patch set. For an actual failure in the areas above, compare hipify-clang on the smallest affected translation unit in a separate output directory. First inspect that version's parsing requirements, includes, defines and compiler options; a missing parse dependency is not evidence that the application is unsupported. Avoid silently installing a CUDA stack to satisfy a diagnostic experiment. Keep a manual declared patch if it is the smaller verified solution.

Consult AMD's version-specific API mappings for runtime, device, BLAS and other used components. Record translation and execution evidence separately:

| Source symbol/location | Translated target | Available in selected stack | Manual adaptation | Compile evidence | GPU semantics test |
| --- | --- | --- | --- | --- | --- |
| Record exact occurrence | Record mapped API or unchanged code | Supported / unsupported / unknown | Patch ID or none | Revision and result | Test or explicit gap |

Audit code not represented by API counters: inline assembly, macros, architecture branches, synchronization assumptions and packed arithmetic. Include the actual header and host-code dependencies. A zero-unsupported report means only that the tool detected no unsupported entries under its coverage; retain independent tests.

Pin translator version/hash/options alongside upstream and patch hashes. Compare a translator upgrade against the same input revision. Regenerate in a temporary directory, apply patches, validate outputs, then publish the successful stamp atomically; never let a failed attempt leave a reusable success stamp. Keep existing generated-source ownership rules.

## Adapt the agent workflow to Strata

The Hugging Face article demonstrates architecture-specific guidance, examples, integration checks and both isolated and end-to-end benchmarks for CUDA/PyTorch workloads. Reuse that process design. Its NVIDIA tuning constants, CUDA extension bindings and distribution commands are not Strata HIP requirements. Do not install the CUDA-focused skill globally or add PyTorch, Nix or Hub packaging without a concrete project need.

Use the following experiment record with the current C++/HIP build and tests:

1. **Contract:** function signature, shapes, strides, dtypes, aliasing, stream ownership and edge cases; exact target GPU/toolchain.
2. **Baseline:** pinned portable implementation, independent oracle, representative real workload and measured bottleneck share.
3. **Hypothesis:** one proposed change, why it could help, predicted costs and predeclared correctness/performance acceptance criteria.
4. **Candidate:** declared source patch, build result and explicit dispatch evidence; preserve fallback.
5. **Validation:** small independent fixtures, adversarial cases, active integration-path checks and unchanged justified tolerances.
6. **Measurement:** warmup, synchronized GPU timing, repeated trials, conversion/launch costs, memory use and complete request latency. Exclude compilation from steady-state timings and report startup separately.
7. **Decision:** retain, reject or investigate; evidence path and next step. Keep existing retry/time budgets.

Apply Amdahl's law to prioritize work: if fraction f of baseline latency is accelerated by factor s, ideal total speedup is 1/((1-f)+f/s), before added overhead. Treat this as an estimate, not a measured outcome. In the article, roughly 1.88x isolated RMSNorm improvement corresponds to about 1.06x end-to-end improvement in one reported video comparison. Do not transfer those H100 measurements to the 7900 XTX or use them as acceptance thresholds.

## Sources

- HIPIFY overview: https://rocm.docs.amd.com/projects/HIPIFY/en/latest/
- Perl usage and limitations: https://rocm.docs.amd.com/projects/HIPIFY/en/latest/how-to/hipify-perl.html
- Clang usage (consult for selected version): https://rocm.docs.amd.com/projects/HIPIFY/en/latest/how-to/hipify-clang.html
- Hugging Face article: https://github.com/huggingface/blog/blob/main/custom-cuda-kernels-agent-skills.md

The experiment record and Strata-specific adaptation are engineering recommendations. No Hugging Face kernel code or benchmark script was installed or tested as part of adding this guidance.
