# rocWMMA for Strata QSA

Use this reference when implementing or reviewing the optional matrix-core scorer. Reviewed AMD documentation on 29 September 2026; the linked latest pages identified themselves as rocWMMA 2.2.1. Recheck against the installed/pinned version.

## Establish compatibility

Treat rocWMMA as a header-based device-kernel building block, not a replacement for HIP launch/runtime code. Prefer an isolated header dependency when compatible; do not rebuild ROCm through TheRock merely to experiment with a scorer.

Record exact header revision, include paths, compiler, target and successful sample execution. Reconcile the fork's historical “v0.8” claim with the actual vendored manifest. Do not infer installed version from ROCm's version number.

Check the architecture-specific precision table rather than the library-wide datatype list. The reviewed table lists gfx11 combinations including FP16/BF16 inputs with FP32 output/accumulation and INT8 with INT32 accumulation. It does not list gfx11 for native FP32-input or xf32 matrix operations. Treat this as the documented rocWMMA combination support, not a claim that ordinary FP32 arithmetic is unavailable on the GPU. Verify exact tile dimensions and support in the selected version with a minimal compile-and-run case.

Read the migration guide before moving to 2.x: it changes cooperative APIs, adds fragment scheduling metadata and supports partial fragments with padding. Do not backport current examples into old headers by guesswork. Pin samples to the same release as headers. Review migration separately from algorithm changes so regressions can be attributed.

## Implement a small candidate

1. Profile the portable QSA scorer at actual model shapes. Record its share of request time before estimating the benefit of matrix cores.
2. Specify the matrix interpretation, leading dimensions, masks, score reductions and output contract. Begin with a simple supported tile, not a highly fused sample.
3. Require every lane in the participating wave to execute the fragment load/store/MMA operations. Handle ragged inputs with verified padding or safe staging; do not put wave-level calls behind per-lane bounds branches. Verify external buffer bounds independently of library fragment padding.
4. Measure LDS and registers, including padded storage. Check device limits and occupancy before increasing tiles or stages. Keep the portable path for unsupported configurations.

## Separate arithmetic changes from implementation defects

Before lowering FP32/TF32-derived inputs to FP16 or BF16, derive a conversion-plus-accumulation bound; FP32 accumulation cannot recover information lost in input conversion. Check overflow, tiny values, cancellation and long reductions. Do not reuse the portable FP32 tolerance without justification.

Use two references: a high-precision mathematical oracle to quantify approximation, and an explicit model of the chosen converted-input arithmetic to isolate kernel defects. Test dimensions below, at and above tile boundaries, nontrivial strides, masks and poisoned padding. Include adversarial near-ties: small score errors can change selected indices. Report selection differences and evaluate downstream logits instead of accepting score error alone. Never tune tolerances to pass the candidate.

## Promote only on evidence

Keep the candidate opt-in. Record dispatch choice so fallback cannot masquerade as accelerated execution. Run representative short and long contexts, warmups and repeated trials; include staging/conversion time as well as kernel time. Compare end-to-end prompt and decode performance, resource peaks and numerical outcomes against the same pinned portable baseline. Retain the simpler path if the gain is not reproducible or correctness changes are unexplained.

## Official sources

- Overview: https://rocm.docs.amd.com/projects/rocWMMA/en/latest/what-is-rocwmma.html
- Programming guide (wave participation and fragment model): https://rocm.docs.amd.com/projects/rocWMMA/en/latest/conceptual/programmers-guide.html
- Precision combinations by architecture: https://rocm.docs.amd.com/projects/rocWMMA/en/latest/api-reference/data-type-support.html
- 2.0 migration: https://rocm.docs.amd.com/projects/rocWMMA/en/latest/conceptual/migration-guide.html

The validation and promotion procedure above is an engineering recommendation for Strata, not an AMD promise of application speedup or model equivalence.

## Measured outcomes on the reference machine (close the open questions above)

- v0.8 cannot compile `mma_sync` for gfx1100 at all (CDNA-only `__builtin_amdgcn_mfma_*`; the overload set is empty) — a fragment-only compile is NOT compatibility evidence. rocWMMA **rocm-7.1.1** (commit 1ab208f) has native gfx1100 support and is **wave32-only on gfx11**; its 16x16x16 fp16→f32 path runs correctly on the card (within 1 f32 ulp of a float64 model — the WMMA unit's internal accumulation order is unspecified, so bounds must be order-agnostic).
- The QSA WMMA arm was implemented as an opt-in path with a pre-derived bound (fp16 conversion ≈ tf32 truncation magnitude; order-agnostic accumulation; flush term): parity 9/9 inside the bound. **Bench verdict: ~2× SLOWER than the portable path at every shape** (0.100 vs 0.035 ms at 65k rows) — the scorer streams pooled F32 and is memory-bound; the fp16 staging round-trip costs more than the tensor cores save. The whole scorer is ~0.1% of a decode step. Verdict recorded: **measured, not promoted** — the portable path stays the default, engine wiring declined with numbers. Revisit only if the scorer's share of decode time changes materially.
