# Serving, tuning and cross-engine measurement

Read when launching the ported engine as a service, tuning its speed flags, or comparing it against another engine. All numbers below were measured on the reference machine (Ryzen 9 7900X, 96 GB RAM, RX 7900 XTX 24 GB, IQ3_S 84 GB model) and recorded in the fork's `artifacts/rocm/results/`; re-verify before relying on them elsewhere.

## Launch as a detached, crash-resistant service

Serve via upstream `serve/server.py` (stdlib HTTP + web UI + OpenAI/Anthropic APIs) as a transient systemd user unit, never inside an agent's own process scope: agent scopes often carry `oom_score_adj=200`, which makes a large model server the OOM killer's first target and takes the harness down with it. Use `systemd-run --user --collect --unit=<name> -p OOMScoreAdjust=-500 -p Restart=on-failure` so the server outranks desktop apps, survives harness crashes and restarts itself. The engine's stderr must be captured in a config `log` key — the default DEVNULL costs a debug cycle on every early exit.

## Hard configuration rules (each one cost a crash to learn)

- **Never all-KV-in-VRAM at context ≥ 64k.** The dense-weights `hipMalloc` (~1.5 GB) then fails during load and the engine exits before READY. Use `--kv int8 --kv-resident 32768` (streaming KV).
- **`--mmap-experts` requires a pack WITH `experts.bin`** (the `iq_pack --experts-bin` output) and its speed depends entirely on where that file lives: on slow storage misses measured 5.6–8 tok/s (unusable); the pinned-arena layout measured 25–43 tok/s. File-backed is the RAM-critical fallback, not the speed path.
- **The arena layout pins ~48 GB of host RAM.** On a 96 GB desktop machine that leaves a thin margin; the pinned-arena OOM chain (four kills) is documented in the fork's PORTING §12d. The durable speed+stability combination on this hardware class is a pruned-expert variant (~24 GB arena).

## Tuning verdicts, measured (keep or revisit with data, not opinion)

- **`--calibrate` (upstream tool): run it first.** On the reference machine its 447 s sweep found the defaults optimal (47.2 tok/s; best alternative within its 3% keep-threshold). It sweeps `--pcie-frac` and `--spec-min-p` through engine restarts with interleaved re-measurement.
- **`--spec 3` is a measured loss at 81% spec-2 acceptance**: deeper drafting dropped acceptance to 55–57% and decode from 38.8–43.3 to ~35.4 tok/s. Deeper drafts only pay when acceptance stays high.
- **`--kv q4_0` is a measured loss here**: decode 43.3 → 36.1 tok/s. The Hadamard rotation cost exceeded what the freed VRAM bought back (the expert tier barely grew). Context-dependent — re-measure on other hardware.
- **`--prompt-cache 6` (default) is the multi-turn win**: follow-up turns reuse the conversation checkpoint (measured "56 reused + 24 read"); trimming it to save RAM only makes sense under memory pressure.
- **Expert-cache hit rate 70% (cold) → 82% (warm) is the healthy range** for this workload. A Monitor dashboard showing low cache numbers right after start is the cold ramp, not a fault. The tier is VRAM-bound (`auto` sizes it after weights/KV); at 65k context it holds ~5.7k of 24.6k experts — misses go to the CPU pool over the arena.
- Tune nothing else before profiling; the scorer-class kernels are ~0.1% of a decode step (see the rocWMMA verdict).

## Cross-engine comparison protocol

Same weights, same tokenizer (so identical prompts and comparable token counts), same GPU, **sequential** runs — never co-resident, both engines want the whole card. Measure decode from each engine's own timing counters (not client wall-clock alone), record prompt/decode/TTFT separately, note RAM/VRAM layouts, and re-run the reference engine after any change so both sides are fresh in the same session. On this model: mainline llama.cpp has upstream `qwen4exp` support and is a valid baseline; vendor forks may predate it (the reference machine's ROCmFPX-serving path does) — check the binary, not the brand. Reference result: Strata 2.1–2.3× llama.cpp decode on identical IQ3_S weights at 65k vs 32k context, identical answers (PORTING §12i).
