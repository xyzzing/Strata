# Context and sources

## Target and inspection limits

Target the user's Fedora PC and RX 7900 XTX (expected gfx1100). Verify local versions and available resources. Preserve the existing model service and files unless changes are explicitly authorized.

Requested fork: https://github.com/xyzzing/Strata

## Fork snapshot retrieved 29 September 2026 (Singapore)

GitHub API and raw-file reads succeeded after initial web/clone retrieval failures. Inspected branch heads:

- `main`: `d551edf42c157f1c8c20f07f68c5dfe506b1edda` (CUDA-oriented upstream tree).
- `rocm-port`: `29ace271ef0357a68f30d5fe4025ae724c64e2b6` (conversion tooling, scripts, patches, tests and reports; upstream sources generated separately).

Read STATUS.md, TASKS.md, PORTING.md, README.md, REPORT.md, handover.md, run.sh, hipify.sh and the translator manifest at the pinned port revision. These are source/document observations, not GPU tests reproduced by this skill's author. Raw hardware logs referenced under local artifact paths were not available as independently reproduced evidence.

| Finding | Evidence and qualification |
| --- | --- |
| Reproducible port machinery exists | hipify.sh exports pinned upstream and uses vendored translator plus declared patches; do not hand-edit generated code |
| Reported kernel result | Latest branch commit message and STATUS report 40 pass / 0 fail / 2 skips; this is repository-reported |
| First generation and API run reported | STATUS records full IQ3_S text generation and loopback 8081 API, with no same-weights logit oracle |
| 32.35 tok/s reported | A short 8-token one-shot example, not an independently reproduced or representative throughput benchmark |
| Version records disagree | Latest commit message says v0.1.18; README/STATUS identify v0.1.16; REPORT identifies d551edf/v0.1.15 |
| Stale state remains | README says both first inference succeeded and no weights/inference; run.sh has pre-inference blocker text |
| Memory problem remains | PORTING section 12d describes a 47.9 GiB pinned expert arena and near-capacity transient use on 96 GB RAM |
| mmap is not yet the IQ fix | Section 12d explains FileExpertSource's fixed Q2_0 blob expectation versus variable-size IQ slices; supersedes earlier mmap advice |
| Serving workaround reported | Detached user service and reduced context; does not remove the underlying memory demand |
| Speculation gap | TASKS records first inference with spec=2 despite speculative kernels being outside the stated initial coverage |
| rocWMMA | Feasibility/compilation reported for v0.8; implementation and measured benefit pending |

Prioritize source/status reconciliation, safe IQ memory access, correct launch packaging and active-path model parity before QSA optimization. Recheck current local evidence; do not freeze these observations into permanent blockers.

Pinned inspection links:

- https://github.com/xyzzing/Strata/tree/29ace271ef0357a68f30d5fe4025ae724c64e2b6
- https://github.com/xyzzing/Strata/blob/29ace271ef0357a68f30d5fe4025ae724c64e2b6/PORTING.md#12d-serving-the-full-iq-model-under-96-gb-ram-the-three-crash-post-mortem
- https://github.com/xyzzing/Strata/blob/29ace271ef0357a68f30d5fe4025ae724c64e2b6/STATUS.md
- https://github.com/xyzzing/Strata/blob/29ace271ef0357a68f30d5fe4025ae724c64e2b6/scripts/rocm/run.sh

Earlier source inspection of **Niko1221/Strata**, revision `6da1f667e86558b152ab128edf3ebf77a80a9e57`, found these investigation targets:

| Historical path | Observation to recheck in the current fork |
| --- | --- |
| `CMakeLists.txt` | Direct CUDA/cuBLAS linkage; note describing omitted original tests/benchmarks |
| `src/core/device.cu` | NVIDIA-specific capability check |
| `src/kernels/cuda/native_qsa_score.cu` | PTX ldmatrix and TF32 mma instructions |
| `src/prefill/gemm.cu` | cuBLAS prefill operations |
| `src/core/graph.cpp`, `pinned.cu`, `verify.cpp` | Graphs, pinned memory and host callbacks |
| `setup.py` | NVIDIA detection/dependency assumptions |

These paths guide discovery only. Their historical state must not cause an agent to redo completed HIP work or assume the fork still omits tests.

## Official references

- Fork: https://github.com/xyzzing/Strata
- Historical upstream: https://github.com/Niko1221/Strata/tree/6da1f667e86558b152ab128edf3ebf77a80a9e57
- HIP porting guidance: https://rocm.docs.amd.com/projects/HIP/en/latest/how-to/hip_porting_guide.html
- HIPIFY: https://github.com/ROCm/HIPIFY
- TheRock overview: https://github.com/ROCm/TheRock
- Release installation/artifacts: https://github.com/ROCm/TheRock/blob/main/RELEASES.md
- GPU support: https://github.com/ROCm/TheRock/blob/main/SUPPORTED_GPUS.md
- Build environment: https://github.com/ROCm/TheRock/blob/main/docs/environment_setup_guide.md
- TheRock target definitions: https://github.com/ROCm/TheRock/blob/main/cmake/therock_amdgpu_targets.cmake
- Compatibility: https://rocm.docs.amd.com/en/latest/compatibility/compatibility-matrix.html

TheRock's overview and release documentation were retrieved for this skill. They describe a ROCm/HIP build-and-release system, prebuilt artifacts, optional component selection, and evolving multi-architecture packaging. The overview estimates approximately 200 GB and multiple hours for a source build; treat this as a broad upstream estimate, not a budget for a specifically minimized build. Prefer an existing working stack, then a suitable isolated prebuilt artifact, before building the toolchain itself.

Refresh version-sensitive references when choosing actual installation commands. Do not copy Ubuntu package commands into Fedora or assume the latest nightly is preferable. TheRock does not translate application kernels or eliminate host-driver requirements.
