# Conditional RCCL and dual-GPU work

Use only for an explicitly selected multi-GPU or multi-node execution design. RCCL supplies collectives and GPU point-to-point communication; it does not partition Strata automatically or combine two 24 GB GPUs into one transparent 48 GB allocation. Keep it optional for the single-GPU build. Independent per-GPU model replicas may require no collectives at all.

## Decision gate

Detect actual devices, target support, PCIe links/root complexes, peer accessibility and transfer bandwidth/latency. Do not assume consumer Radeon links behave like Instinct xGMI. Verify the selected RCCL release supports the exact deployment; ROCm support alone does not establish a fast, tested RCCL configuration. Start from measured one-card inference.

Trace tensor/expert ownership and traffic for candidate layer, expert or tensor partitioning. Estimate per-token bytes, synchronization count and replicated versus sharded state. Choose RCCL only where collectives or its point-to-point semantics solve a concrete communication need; direct HIP copies may suffice for simpler placement. Measure batch-one latency as well as large-message throughput. The fastest collective microbenchmark need not yield the fastest inference.

## Integration checks

RCCL retains nccl-prefixed API names; inspect headers and loaded libraries instead of blindly renaming symbols. Define unique ranks, device mapping, communicator lifecycle and agreement on operation order, counts, types and roots. Calls enqueue stream work: successful return is not completed communication. Preserve buffer lifetime and compute/communication dependencies. Inspect grouping requirements when one thread controls multiple devices.

Before engine integration run supported correctness tests on all selected devices at realistic message sizes. Then compare distributed outputs/state with the same-weights baseline, including routing ties and changed floating-point reduction order. Validate repeated requests, rank failure/timeout, cancellation and cleanup of owned workers. Check API availability in the installed release before using modern error-recovery functions. Reject outputs from aborted/incomplete collectives; communicator recovery alone cannot reconstruct missing model shards or recurrent state.

Keep communication buffers in per-device/host memory budgets. Do not increase shared-memory limits, disable IOMMU/ACS/security controls or change system configuration automatically as a tuning recipe. Diagnose and propose necessary changes concretely. Preserve single-GPU fallback and avoid automatically taking a second card away from another service.

## Source/version notes

Reviewed AMD RCCL overview and API documentation on 29 September 2026; pages identified RCCL 2.30.4. APIs and packaging must be checked against the actual installed version. Current docs point to rocm-systems; the standalone ROCm/rccl repository is marked retired. Use pinned historical source only when intentionally matching an older stack.

- https://rocm.docs.amd.com/projects/rccl/en/latest/
- https://rocm.docs.amd.com/projects/rccl/en/latest/what-is-rccl.html
- https://rocm.docs.amd.com/projects/rccl/en/latest/api-reference/library-specification.html
- https://github.com/ROCm/rocm-systems

The placement, admission and testing steps are recommendations for this project; they do not claim the current fork already supports multiple GPUs. No RCCL execution was tested while creating this skill.
