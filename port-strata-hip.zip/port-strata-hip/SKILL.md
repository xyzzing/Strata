---
name: port-strata-hip
description: Continue, diagnose, implement and validate Strata CUDA-to-HIP conversion on AMD ROCm, especially xyzzing/Strata on Fedora with RX 7900 XTX (gfx1100). Use for HIPIFY, GPU kernel parity, CMake backend work, ROCm toolchain failures, rocWMMA QSA optimization, bounded automatic speed tuning, conditional multi-GPU/RCCL design and deciding whether TheRock is needed. Inspect existing progress before editing; exclude unrelated AMD installation and general model prompting.
---

# Strata HIP engineering and measured optimization

Advance the existing port by the smallest verified milestone. Treat this skill as agent instructions, not an already implemented autonomous optimizer. Detect whether the project has an executable tuning harness and implement missing controls before claiming automatic optimization works. Preserve completed work and report evidence rather than a guessed completion percentage. Treat a successful build, GPU kernel correctness, model correctness and useful performance as separate outcomes.

## Establish the current state

1. Read applicable repository instructions. Resolve the user's actual checkout, branch, full revision and dirty files. Prefer their existing checkout; do not restart from upstream or replace local changes.
2. Enumerate branches before judging progress: the inspected fork keeps conversion tooling on `rocm-port`, while `main` is CUDA upstream. Inspect README, status/task/porting documents if present, recent changes, build presets, backend selection, tests, CI and existing wrappers. Discover paths rather than assuming this skill's example names exist.
3. Compare source with claims. Label each capability **implemented**, **build-tested**, **GPU-tested**, **model-validated**, **unverified**, or **blocked**, recording revision, environment and evidence path. A CI badge or narrative status without relevant logs is not GPU validation.
4. Inspect changed HIP files and remaining CUDA dependencies in host code, headers, kernels, build scripts and packaging. Separate active paths from intentionally preserved CUDA paths. Do not treat every CUDA string as unfinished work.
5. Select the first unmet gate in the actual dependency graph. Reuse existing tests and wrappers; do not create a competing progress system or re-HIPIFY already maintained HIP code.

Use `git status --short`, `git log -8 --oneline`, `rg --files` and targeted `rg` searches for `HIP|ROCM|CUDA|hipblas|cublas|asm|__shfl|__dp4a|Graph|LaunchHostFunc`. Scope expensive output to relevant files. Check remote progress only when accessible; never infer that an inaccessible fork is private, empty or unchanged. If remote access fails, request the checkout/archive or status and diff evidence, while completing useful generic work.

Read [references/context-and-sources.md](references/context-and-sources.md) for historical observations and source links. Never use historical upstream findings as proof of the fork's present state.

## Continue this fork without restarting it

At the inspected `rocm-port` revision, retain the reproducible generated-source workflow: pinned upstream checkout, hash-pinned HIPIFY, declared patches in `scripts/rocm/patches/`, and regeneration. Edit the patch/rule source and tests, not generated HIP files. Inspect how stamps hash the upstream revision, translator and patches; ensure a failed generation cannot be reused as a successful cache hit.

Use this initial priority order, revising it when fresh evidence warrants:

1. Reconcile contradictory README/STATUS/REPORT/handover notes with actual source, manifests and test records. Distinguish the tooling revision from the nested upstream revision. The snapshot names upstream v0.1.15, v0.1.16 and v0.1.18 in different places; verify the actual pin and tested revision rather than choosing the newest claim.
2. Address the IQ expert-memory path and host-memory admission before repeated full-model runs. Read PORTING section 12d: older notes claiming `--mmap-experts` solves this are superseded by an analyzed format mismatch. Validate any proposed fix against actual code.
3. Verify the launch wrapper against the real engine/API contract. The inspected `run.sh` ends with only `--host/--port` and carries stale pre-inference text, while documented successful serving uses upstream Python serving plus artifacts/configuration. Inspect CLI support; implement and test a complete artifact-aware launch rather than declaring the wrapper release-ready.
4. Close same-weights model parity and active speculative/PLE/CPU-expert coverage; exercise repeated requests and state reset. First generation used `--spec 2`; a test scope labeled non-speculative cannot certify that run. Inspect whether a genuine no-spec baseline is supported before proposing one.
5. Optimize the QSA scorer with an opt-in rocWMMA path only after memory stability and applicable parity gates. A compile-tested rocWMMA prototype is not a completed fast path. Keep the portable path as the reference/default until measured improvement and justified numerical bounds pass.

For memory work, measure available host memory, cgroup limits, locked pages, page-cache/transient peaks and other services. Detaching into a service changes lifecycle/OOM selection; it does not fix excess memory demand. Refuse predictably unsafe launches and preserve an explicit memory reserve. Design IQ file-backed access around verified per-layer offsets, sizes and quantization layouts; test file bounds, lifetime, expert IDs, random rows and CPU outputs before comparing logits/tokens against the arena path. Do not interpret mapping source GGUF files during loading as proof the runtime arena is file-backed.

Run a reference engine sequentially when simultaneous residency is impossible and an authorized memory window is available. Capture comparable layer/logit fixtures, unload, then compare; verify exact model support first. Do not abandon independent parity solely because two models cannot fit simultaneously, and do not stop the existing server without authorization.

## Diagnose the environment before changing code

Detect Fedora/kernel, all GPU identities and visibility, per-device free VRAM, host RAM, disk space, HIP compiler, CMake, runtime and BLAS versions. Earlier conversation described one 7900 XTX; the merged attachment describes an intended two-card host. Measure the actual GPU count, PCIe topology and workload ownership; do not silently choose either assumption. Inspect existing visibility/architecture overrides without resetting them. Confirm gfx1100 on the target rather than spoofing another architecture. Check GPU access using available diagnostics, then compile and run a tiny allocation/arithmetic test on the selected device.

Classify failures before repair:

| Failure | First investigation |
| --- | --- |
| HIP smoke test cannot run | Device access, host driver, runtime/toolchain compatibility |
| Configure/compiler failure | Selected compiler, CMake HIP setup, flags and header paths |
| Link/load failure | Library paths, exported symbols, ABI and mixed installations |
| Numerical mismatch | Layout, packing, datatype, reduction, masks and rounding |
| Hang only with overlap | Stream/event ordering, host callback lifetime and memory visibility |
| Correct but slow | Profile the validated path; distinguish transfer, CPU and GPU costs |

Keep one coherent compiler/runtime/BLAS stack per build directory and launch environment. Record resolved paths and loaded libraries, not just PATH or package labels. Do not mix system ROCm and TheRock libraries accidentally. Isolate environments with project launch scripts; leave global shell files, drivers and existing model services untouched unless the user has authorized changes.

## Decide whether TheRock helps

Treat TheRock as a ROCm build/release and dependency source, not an application transpiler or substitute for correctness tests.

Use this order:

1. Retain a working existing ROCm stack if it supports the required APIs and target.
2. If a specific toolchain/library issue blocks progress, identify the needed fix and investigate an official prebuilt TheRock release in an isolated location. Prefer a pinned stable compatible release; use a nightly only for a demonstrated need and record its exact version.
3. Build ROCm from source only when available artifacts cannot address the proven blocker. Scope to gfx1100 and required compiler/runtime/HIP/BLAS/HIPIFY components. Read the selected revision's flags and dependencies first; do not guess names or reuse stale commands.

Before adopting an artifact, verify supported target, Fedora/glibc and host-driver compatibility, compiler/development headers, runtime/BLAS dependencies, package origin and available checksums. Read the selected release's documentation: multi-architecture versus older per-family packaging changes installation syntax. A Python package installation alone does not prove a complete C++ build environment.

Use separate build directories for stack comparisons. Re-run the smoke test and affected numerical gates after switching. Propose concrete size/time/system changes before a large source build when not already authorized. Do not build PyTorch, JAX or unrelated ROCm components merely to port Strata.

## Validate artifacts and profile the actual engine

Trace a real tensor from the model manifest/GGUF reader through dequantization, dispatch and output. Validate format version, typed metadata, dimensions, quant types, alignment, offsets, shard completeness and byte ranges. Match tokenizer/MTP/PLE sidecars to the selected model; filenames are hints, not an architecture contract. GGUF is a storage format, not proof of a particular executor or full ggml compatibility. Keep original model files immutable. Consult the [GGUF specification](https://github.com/ggml-org/ggml/blob/master/docs/gguf.md) and the implemented reader subset.

Profile prefill and decode separately after a correct baseline exists. Use installed profiler help and architecture-supported metrics; do not transplant MI-series counters to Radeon. Separate instrumented diagnosis from uninstrumented timing, kernel dispatch time from wall-clock latency, and cold load from steady state. Inspect transfers, expert-cache hits, CPU work and memory stalls before naming a GPU kernel bottleneck. Never remove a reference check, reduce requested context or change quantization/sampling to manufacture a speedup.

## Port with numerical discipline

- Preserve CUDA support and artifact formats. Follow the existing backend architecture. If none exists, introduce a small shared runtime abstraction plus targeted backend implementations; document generated versus hand-maintained files.
- Use HIPIFY for mechanical API translation, then inspect the diff. Include CUDA-dependent `.cpp` and headers. Do not blindly replace source text or NVCC flags. Read [references/translation-and-kernel-loop.md](references/translation-and-kernel-loop.md) for translator selection, coverage records and the bounded kernel experiment contract. Preserve the pinned Perl translator unless a demonstrated failure justifies a scoped Clang comparison; zero reported unsupported APIs is not proof of semantic coverage.
- Configure CMake HIP compilation with a compatible compiler and explicit detected architecture. Link supported HIP runtime/BLAS targets and verify exact APIs against the chosen stack. Do not present proposed project flags as existing commands.
- Audit PTX, Tensor Core fragment layouts, TF32 rounding, inline assembly and architecture guards. Replace unsupported instructions with a correct HIP/reference implementation before tuning. Do not map NVIDIA matrix fragments directly to AMD intrinsics.
- Audit shuffle masks, subgroup widths, active lanes, barriers, reductions and partial groups. Do not mechanically change 32 to 64: inspect the actual wave/subgroup requirements on RDNA3.
- Audit signed/unsigned INT8 dot products, packed quantization blocks, overflow and alignment. Test explicit rounding, BF16/FP16 conversions, fused operations and accumulation precision. Do not change quantization to disguise a backend mismatch.
- Verify BLAS transposes, leading dimensions, strides, datatypes, alpha/beta semantics and workspace lifetime against independent small matrices.
- Preserve model masks, sparse indexing, routing tie behavior, recurrent state and cache updates. Test multiple steps, not only the first token.
- Establish a synchronous debug path. Restore streams, CPU expert overlap, pinned memory, host callbacks and graphs individually. Use explicit synchronization and valid ownership/lifetimes; do not rely on volatile flags as a general memory-ordering solution.

## Evaluate a rocWMMA fast path

Read [references/rocwmma-qsa.md](references/rocwmma-qsa.md) before selecting rocWMMA datatypes, tiles, samples or upgrades. Pin the actual header version and compiler; the fork's historical v0.8 note is not proof of compatibility with current 2.x examples. Treat precision conversion as a semantic change requiring its own error analysis. Keep all lanes participating in wave-level operations and test edge tiles without out-of-bounds access. Retain portable fallback and accept a fast path only after independent numerical checks, downstream selection checks and end-to-end measurements. rocWMMA does not resolve the IQ expert arena's host-memory problem.

## Require staged evidence

| Gate | Minimum evidence |
| --- | --- |
| Toolchain | Tiny HIP program executes on the actual device |
| Kernels | Independent references cover active operations, quantization and boundaries |
| Integration | Actual required forward-pass path builds and executes without stubs or silent CPU substitutions |
| Model | Same weights/tokenizer/input; independent layer/logit or verified reference comparison |
| Scheduling | Repeated requests, state reset, cancellation and overlap agree with debug behavior |
| Performance | Reproducible before/after measurements on correctness-validated configurations |

Use independent CPU mathematical references, trusted fixtures or a verified implementation of the exact model. Record fixture provenance and checksums. Comparing two paths sharing the same faulty implementation is regression evidence, not independent validation. If the reference is missing, preserve the parity blocker even if generated text is fluent.

Require exact agreement for defined integer/packing operations. Predeclare justified floating-point tolerances by datatype, scale and reduction length; record absolute/relative error and nonfinite values. Handle near-ties explicitly for routing/top tokens. Never widen tolerances to hide unexplained divergence. Include negative tests proving the harness detects a known defect. Count skipped, unavailable and xfailed tests separately from passing tests.

Begin with text-only, one request, short context and speculation disabled unless current evidence already validates later stages. Before downloading new weights, inspect approved existing artifacts, sizes, conversion workspace and RAM/VRAM requirements. Do not assume earlier authorization was absent; honor current user permissions.

Validate speculative acceptance/rejection and cache/recurrent rollback before enabling it. Do not promise bitwise vendor equality or preserved distributions without appropriate evidence.

## Run bounded automatic optimization

Read [references/automatic-optimization.md](references/automatic-optimization.md) when asked to tune speed or run autonomously. Adapt [assets/optimization-policy.example.yaml](assets/optimization-policy.example.yaml) into the repository's existing configuration; it is an inactive example, not a recognized Strata command or executable controller.

Establish an immutable baseline, explicit workload objective, fixed correctness thresholds, memory/resource reserve and run budgets. Execute the state sequence: **preflight → baseline → profile → hypothesis → isolated candidate → build → correctness → paired benchmark → holdout → accept/reject → checkpoint**. Save decisions deterministically outside the LLM. Never let the optimizer modify the evaluation gates to certify its own candidate.

Stage autonomy: first supervised baseline and harness self-tests; then bounded local candidate trials; only then unattended trials after stop, crash recovery and rollback have been exercised on the actual host. Existing user authorization covers ordinary in-scope edits/tests; do not ask for approval per candidate. Pause for materially new spending, system changes, service interference or expanded scope. Do not promote to a running service automatically.

Read [references/rccl-and-multi-gpu.md](references/rccl-and-multi-gpu.md) only when the chosen measured partitioning needs multi-device communication. Keep one-GPU tuning as the initial baseline. Two cards do not provide a transparent combined allocation; RCCL does not fix IQ expert arena memory management or accelerate single-card arithmetic.

## Automate bounded progress

Use existing project build/test/report commands. Implement missing repeatable checks as scripts rather than repeatedly improvising terminal commands. Capture complete logs and exit codes with subprocess timeouts. A timeout is not a numerical failure; a compile-only test is not a GPU pass.

Honor explicit budgets. Otherwise start with three repair attempts per distinct failure, checkpoints within 60 minutes and small-test timeouts around 120 seconds, extending only for a justified workload. After repeated failure, change the hypothesis or preserve a blocker; do not retry unchanged evidence indefinitely. Report cost as unknown if provider accounting is unavailable.

Continue authorized reversible edits and tests without milestone permission loops. Ask only for unresolved decisions that materially affect system state, spending, downloads, other services or disclosure. Stop only owned processes; do not reset the GPU or kill an existing server as an automatic repair.

Persist current revision/patch, environment, commands, evidence, failed attempts and next action using the repository's existing records. Invalidate affected test evidence after relevant source/toolchain changes. Keep model weights and credentials out of commits and logs.

For difficult blockers, prepare a minimal handoff: question, reproducer, expected/actual behavior, versions, attempted fixes and acceptance test. Reuse verified answers. Do not send to another provider without existing authorization.

## Serve and tune from measured verdicts

Read [references/serving-and-tuning.md](references/serving-and-tuning.md) before launching the engine as a service, changing speed flags, or comparing engines. Detached systemd unit with negative OOM adjustment (agent scopes inherit oom_score_adj=200); streaming KV at large contexts (all-VRAM KV at 64k+ fails the dense-weights allocation); mmap experts only with experts.bin on fast storage; the calibrated defaults, the measured losers (deeper spec drafts at mid acceptance, q4_0 KV on this hardware) and the prompt-cache reuse win; expert-cache hit rates of 70-82% being the healthy warm range rather than a fault.

## Finish with a usable report

State what works, what is unverified, the current blocker and the next concrete action in plain language. Distinguish source inspection, repository-reported tests and tests personally reproduced. Include measured prompt processing, generation, first-token latency and memory only when actually benchmarked with recorded settings. Use three or more repetitions for comparisons, report spread, and never extrapolate NVIDIA throughput to AMD.

On successful local completion provide a tested launch command, isolated environment and rollback procedure. On partial completion leave a reproducible checkpoint. Do not claim a production-ready port or modify the fork remotely merely because this skill was invoked.
